#ghaziConverter
Vous partez en voyage et vous souhaitez connaître la monnaie et le taux de change du pays de votre destination ? 
Choisissez cette application!
C'est un convertisseur de devises gratuit utilise les taux de change quotidiens filtrée utilisée par les entreprises d'audit et les banques.


